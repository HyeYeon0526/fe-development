let p1 = { name : "홍길동", age: "16" };
let p2 = { name : "임꺽정", age: "18" };

let a = [p1,p1,p2];

console.log(p1); 
console.log(p2); 
console.log(a);