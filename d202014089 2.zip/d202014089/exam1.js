function print(a) {
    let type = typeof(a);
    console.log(type);
}

print(true);
print("hello world"); 
print();