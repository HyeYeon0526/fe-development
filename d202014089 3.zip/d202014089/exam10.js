let a1 = [1, 2]; 
let a2 = [a1, a1, a1];

a2[0][0] = 10; 
console.log(a2);